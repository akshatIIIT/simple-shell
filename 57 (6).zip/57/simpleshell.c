#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>
#include <sys/time.h>
#include <errno.h>

#define MAX_INPUT_SIZE 1024
#define MAX_ARG_SIZE 100
#define HISTORY_SIZE 100

char *history[HISTORY_SIZE];
int history_count = 0;

void print_prompt() {         // always printing SimpleShell> before executing any command and flushing out the terminal
    printf("SimpleShell> ");
    fflush(stdout);
}

void launch(char **args, int input_fd, int output_fd, int background) {
    pid_t pid;

    if ((pid = fork()) == 0) { // Child process
        if (input_fd != -1) {          // writing into pipe directly
            dup2(input_fd, STDIN_FILENO);    
            close(input_fd);
        }
        if (output_fd != -1) {         // reading from pipe directly
            dup2(output_fd, STDOUT_FILENO);
            close(output_fd);
        }
        execvp(args[0], args);
        perror("execvp failed");
        exit(EXIT_FAILURE);
    } else if (pid < 0) {              // checking if child process creation has failed or not
        perror("fork failed");
    }

    if (!background) {
        waitpid(pid, NULL, 0); // Wait for foreground process
    }
}

void parse_and_execute(char *input) {
    char *args[MAX_ARG_SIZE];
    char *commands[MAX_ARG_SIZE];
    int num_commands = 0;
    char *token = strtok(input, "|");
    
    // separating pipe command input into separate commands
    while (token != NULL) {
        commands[num_commands++] = token;
        token = strtok(NULL, "|");
    }

    int pipe_fds[2];
    int input_fd = -1;
    
    int i = 0; 

    while (i < num_commands) {
        char *cmd = commands[i];
        int output_fd = (i == num_commands - 1) ? -1 : pipe_fds[1];
        
        if (i < num_commands - 1) {
            if (pipe(pipe_fds) < 0) {           // making sure that commands send data into pipes properly
                perror("pipe failed");
                exit(EXIT_FAILURE);
            }
        }

        char *args[MAX_ARG_SIZE];
        int j = 0;
        token = strtok(cmd, " \n");
        int background = 0;

        // Check for background execution
        while (token != NULL) {
            if (strcmp(token, "&") == 0) {                //checking whether '&' exists
                background = 1; // Set background flag
                break;
            }
            args[j++] = token;
            token = strtok(NULL, " \n");
        }
        args[j] = NULL;

        launch(args, input_fd, output_fd, background);
	//closing file descriptors of pipe
        if (input_fd != -1) {
            close(input_fd);
        }
        if (i < num_commands - 1) {
            close(pipe_fds[1]);
        }
        input_fd = pipe_fds[0];

        // If the command is background, no need for waiting
        if (background) {
            printf("Background process started with PID: %d\n", getpid());
        }
        i++;
    }

    // Wait for all child processes to complete
    for (int i = 0; i < num_commands; i++) {
        wait(NULL);
    }
}

void add_to_history(const char *cmd) {  // history command addition
    if (history_count < HISTORY_SIZE) {
        history[history_count] = strdup(cmd);
        history_count++;
    } else {
        free(history[0]);
        memmove(history, history + 1, (HISTORY_SIZE - 1) * sizeof(char *));
        history[HISTORY_SIZE - 1] = strdup(cmd);
    }
}

void print_history() {  //history printing
    for (int i = 0; i < history_count; i++) {
        printf("%d: %s\n", i + 1, history[i]);
    }
}

int main() {    //simpleshell code execution
    char input[MAX_INPUT_SIZE];

    while (1) {
        print_prompt();
        if (fgets(input, sizeof(input), stdin) == NULL) {
            perror("fgets failed");
            exit(EXIT_FAILURE);
        }

        // Remove trailing newline character
        size_t len = strlen(input);
        if (len > 0 && input[len - 1] == '\n') {
            input[len - 1] = '\0';
        }

        if (strcmp(input, "exit") == 0) {
            break;
        }

        if (strcmp(input, "history") == 0) {
            print_history();
            continue;
        }

        add_to_history(input);
        parse_and_execute(input);
    }

    // Free history
    for (int i = 0; i < history_count; i++) {
        free(history[i]);
    }

    return 0;
}

